<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function onetomany()
    {

        /* #Comment: Many to Many  [hasMany] relationship and inverse [belongsTo] relationship */
        
        /* it's working better if we want to get all data from both table' */
        $data = Customer::with('order')->get();
        return $data;

        /* Get Both Table perticular column  Data */
         /* it's working fine because we define inverse function in laravel */ 
         /* but in this case we use inverse relation function also in second model */
         /*its not good way */
    // $data= Customer::with(['order' => function ($query) {
    //     $query->select('order_id','order_name', 'customerid');
    // }, 'order.customer' => function ($query) {
    //     $query->select('customer_id', 'customer_name');
    // }])->get();
    //     return $data;



    /* Get Both table perticular column  Data */
    /* Always use this */
     /* in orders table id we also define in this which related from customer table */
        /* if we want to get both table data then we define both table  relation ids as(customers table [cust_id -> which is foreign key in orders table]) */
        /* //in orders table id we also define in this which related from customer table (as order table foreign key 'customerid'[which come from customers table]) */
        /* For get both table data we use both table id [which common in both table] */

        // $data = Customer::with(['order' => function ($query) {
        //     $query->select('order_name', 'customerid');
        //     }])->select('customer_name','cust_id' , 'city')
        //     ->get();
        //     return $data;
     

            /* For Details understanding  reads this*/
        /* in orders table id we also define in this which related from customer table */
        /* if we want to get both table data then we define both table  relation ids as(customers table [cust_id -> which is foreign key in orders table]) */
        /* //in orders table id we also define in this which related from customer table (as order table foreign key 'customerid'[which come from customers table]) */
        /* For get both table data we use both table id [which common in both table] */
    //  $data =   Customer::with(['order' => function ($query) {
        // $query->select('order_name', 'customerid');   //in orders table id we also define in this which related from customer table (as order table foreign key 'customerid'[which come from customers table])
    // }])->select('customer_name','cust_id' , 'city')  //if we want to get both table data then we define both table  relation ids as(customers table [cust_id -> which is foreign key in orders table])
    // ->get(); //if both id is passed then both table data will be fetched
// return $data;




/* it is only for testing, in case of has many relation*/
           // $data = Customer::with('order:order_id,order_name')
        // ->select('customer_id', 'customer_name', 'city')
        // ->get();

       /* Using query builder relation */
       /* left join -> it's return left table all data and [from right table->] that data which is common in both table */
       /* left table means [table who written 1st[1st table] in query] */

        // $data = DB::table('customers')->select('customers.customer_name', 'customers.city', 'orders.order_name')
        // ->leftJoin('orders', 'customers.customer_id', '=', 'orders.customerid')
        // ->get();
        // return $data;

        //  $data = DB::table('customers')
        // ->leftJoin('orders', 'customers.customer_id', '=', 'orders.customerid')
        // ->get();
        // return $data;

        // $data = DB::table('customers')
        // ->leftJoin('orders', 'customers.cust_id', '=', 'orders.customerid')
        // ->get();

        // return $data;

        /*Right join -> it's return right table all data and [from left table-> ] that data which is common in both table  */
        /* right table means [table who written 2nd[2nd table] in query] */
        // $users = DB::table('customers')
        //     ->rightJoin('orders', 'customers.customer_id', '=', 'orders.customerid')
        //     ->get();
        //     return $users;
    
 /* Join/Inner Join return both table common data[return row, which id matched in both table] */
            //  $data = DB::table('customers')
            // ->join('orders', 'customers.cust_id', '=', 'orders.customerid')
            // ->select('customers.*', 'orders.order_name')
            // ->get();
            // $data = DB::table('customers')
            // ->join('orders', 'customers.customer_id', '=', 'orders.customerid')
            // ->select('customers.*', 'orders.order_name')
            // ->get();
            // return $data;

    }


    public function onetoone()
    { 
        /* #Comment: One to One relation [hasOne] */
        $data = Customer::with('orderone')
        ->get();
        return $data;
    }
}
