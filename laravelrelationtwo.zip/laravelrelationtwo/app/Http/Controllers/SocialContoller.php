<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Client;
use Illuminate\Http\Request;

class SocialContoller extends Controller
{
    /* this relation get multiple data */
    /* isme 3 table ki need hoti hai */ 
    /* in this relationship, for creating 'pivot table/intemidiate' table we follow some rule 
        a). pivot table name is singular
        b). pivot table name is combination of both table name
        c). pivot table is follow alfabetical order
        Ex-> users, posts table and iska pivot table name 'post_user' hoga according to alfabet order and dono table ka 1st charecter same hai then 2nd charecter ka order check karenge[jb tk diffrent nhi hoga tab tak]
    */
    /* 1st and 2nd table ki primary key ka name 'id' hi hona chahiye ise hum customize nhi kar sakte [customize karne per error through karega] */
         //syntax -> belongsToMany(Modelname, 'pivot tablename', 'foreignkey 1st[jis model me work kar rhe hai uski foreign key in pivot table]', 'foreignkey 2nd [jis model ke sath relation banana hai uski foreign key in pivot table]')
        /* 
            modelname -> us model ka name jiske sath relation banana hai
            pivot table-> intermidiate table name (jisme dono table ki id exist karegi) [isme table name singular hona chahiye and alphabetical]  [rule study kare net se(demonuts se)]
            'foreignkey 1st' -> jis model me work kar uski foreign in pivot table [foreign key of local table in pivot table]
            'foreign key  2nd -> jis model ke sath relation banana hai uski foreignt key in pivot tabl [foreign key of relation model in pivot table] 
        */
    public function manytomany()
    {
        // $data = Client::with('postdata')->get();
        // return $data;

        $data = Post::with('clientdata')->get();
        return $data;
    }
}
