<?php

namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;

class CollegeController extends Controller
{
    /* #Comment:: get one date from last table */
    /* hasonethrough relation need 3 table (first,intermidiate,last) */
    /* in hasonethrough relationship we get last table(model) data from first table(model) via intermidiate table(model) */
    /* in hasonethrough relationship, 1st table se last table ka data direct get na karke via intermidiate table se fetch karte hai */
    /* isme 1st aur 3rd table ka direct intraction nhi hota */
    /* intraction ke liye hum middle(intermidiate) table ka use karte hai */ 
    /* isme hum ek  id ke base pe  r last table[via intermidiate table] se single row fetch karte hai [agar kai row ke sath relation hai phir bhi ye one row hi return karega] */
    public function hasonethrough()
    {
        $data = Project::with('task')->get();
        return $data;
    }

     /* #Comment:: get one date from last table */
    /* hasmanythrough relation need 3 table (first,intermidiate,last) */
    /* in hasmanythrough relationship we get last table(model) data from first table(model) via intermidiate table(model) */
    /* in hasmanythrough relationship, 1st table se last table ka data direct get na karke via intermidiate table se fetch karte hai */
    /* isme 1st aur 3rd table ka direct intraction nhi hota */
    /* intraction ke liye hum middle(intermidiate) table ka use karte hai */ 
    /* hasmanythrough me ek id ke base per last table[via intermidiate table] se multiple row fetch ho sakte hai */
    public function hasmanythrough()
    {
        $data = Project::with('taskmany')->get();
        return $data;
    }
}
