<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;
    protected $table = 'clients';

    public function postdata()
    {
        
        return $this->belongsToMany(Post::class, 'client_post', 'clientid', 'postid');
        
            //syntax -> belongsToMany(Modelname, 'pivot tablename', 'foreignkey 1st[jis model me work kar rhe hai uski foreign key in pivot table]', 'foreignkey 2nd [jis model ke sath relation banana hai uski foreign key in pivot table]')
        /* 
            modelname -> us model ka name jiske sath relation banana hai
            pivot table-> intermidiate table name (jisme dono table ki id exist karegi) [isme table name singular hona chahiye and alphabetical]  [rule study kare net se(demonuts se)]
            'foreignkey 1st' -> jis model me work kar uski foreign in pivot table [foreign key of local table in pivot table]
            'foreign key  2nd -> jis model ke sath relation banana hai uski foreignt key in pivot tabl [foreign key of relation model in pivot table] 
        */
    }
}
