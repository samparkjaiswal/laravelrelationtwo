<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    protected $table = 'customers';

    /* #Comment:: for one to many relationship */
    public function order()
    {
        return $this->hasMany(Order::class, 'customerid', 'cust_id');
    }

    /* #Comment:: for one to one relationship */
    public function orderone()
    {
        return $this->hasOne(Order::class, 'customerid', 'cust_id');
    }


}
