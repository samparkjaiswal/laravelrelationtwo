<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    protected $table = 'projects';
    /* HasoneThrough relational method */
    public function task()
    {
        return $this->hasOneThrough(
            Task::class,  //Last table which data we want to fetch
            Student::class, //Intermidiate table which through we fetch last table data
            'pro_id', // Foreign key on student table...
            'std_id', // Foreign key on task table...
            'project_id', // Local key on projects table OR Local key on 1st Table[that table where we create relation]
            'student_id' // Local key on students table OR Local key on intermediate table
        );
    }

    public function taskmany()
    {
        return $this->hasManyThrough(
            Task::class,  //Last table which data we want to fetch
            Student::class, //Intermidiate table which through we fetch last table data
            'pro_id', // Foreign key on student table...
            'std_id', // Foreign key on task table...
            'project_id', // Local key on projects table OR Local key on 1st Table[that table where we create relation]
            'student_id' // Local key on students table OR Local key on intermediate table
        );
    }
}
