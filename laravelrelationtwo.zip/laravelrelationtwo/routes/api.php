<?php

use App\Http\Controllers\CollegeController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\SocialContoller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });


Route::get('/datas', [OrderController::class, 'onetomany']);
Route::get('/data', [OrderController::class, 'onetoone']);
Route::get('/row', [CollegeController::class, 'hasonethrough']);
Route::get('/rows', [CollegeController::class, 'hasmanythrough']);
Route::get('/many-to-many', [SocialContoller::class, 'manytomany']);